// JavaScript code for CTA section

const ctaBtn = document.querySelector('.cta .btn');

ctaBtn.addEventListener('click', () => {
    // Open application form or redirect to application page
    console.log('Application button clicked');
});
