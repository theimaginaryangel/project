// JavaScript.js

const contactForm = document.getElementById('contact-form');

